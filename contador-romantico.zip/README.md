# Contador Romântico

Página estática em HTML, CSS e JavaScript puro. Abra `index.html` diretamente no navegador. Todos os recursos são locais e não há instalação, build ou servidor obrigatório.

O destino é **27/10/2026 às 00:00 em America/Belem**, configurado como `2026-10-27T00:00:00-03:00` (03:00 UTC). O contador usa timestamps reais, atualiza a cada segundo e para em zero. O relógio do dispositivo deve estar correto.

## Publicar no GitHub Pages

1. Crie ou utilize um repositório no GitHub.
2. Envie `index.html`, `style.css`, `script.js` e a pasta `assets/` para a raiz da branch principal.
3. Abra **Settings → Pages**.
4. Em **Build and deployment**, selecione **Deploy from a branch**, a branch principal (normalmente `main`) e a pasta **/(root)**.
5. Salve e aguarde o GitHub exibir o endereço publicado.

A disponibilidade do Pages para repositórios privados depende do plano da conta. Este projeto não requer serviços pagos.

## Arte e responsividade

No desktop (larguras a partir de 601px), a página usa `assets/arte-desktop.png`, a imagem horizontal fornecida pelo usuário, sem alterações. No celular, mantém `assets/arte-romantica.png`, uma adaptação feita com a ferramenta integrada de imagens a partir do mockup, removendo dispositivos e interface para permitir o contador real. Não é uma extração pixel a pixel da ilustração original. A seleção das imagens é feita com HTML `<picture>`. No desktop, `object-fit: cover` preenche toda a tela sem margens e sem deformação. O enquadramento em `center 75%` prioriza os lobinhos; as bordas da arte podem ser recortadas conforme a proporção da tela.

Prompt utilizado: “Extract and restore the flat illustration inside the laptop screen as a standalone portrait website background. Remove all text, countdown cards, numbers, date and browser/device hardware. Preserve faithfully the dark purple and pale lilac wolf couple hugging with eyes closed on a rock, pink-purple lakeside mountains, town, reflections, flowers, starry purple sky and pink crescent. Top 60 percent open sky for HTML counter; wolves centered below, fully visible with tails and rock, pink heart above. Match original outlines, texture and colors. No typography, UI or frames.”

## Verificação

Sintaxe JavaScript e cálculo conferidos para um dia antes, um segundo antes, o instante exato e depois do destino. Conferida também a prevenção de intervalos duplicados e a limpeza ao sair da página.

